/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model.DAO;

import java.sql.*;
import model.Curriculo;
import config.ConectaDB;
import java.util.ArrayList;
import java.util.List;

        
/** @author Matheus e Thais
 * Data: 28/08/2025
 * 
 *   Nome
                Email
                Telefone
                Formação
                Experiência
                Habilidades
                Linkedin
                Portfolio
                Salario
 * 
 */
public class CurriculoDAO {
    // Atrib
    
    //Métodos - CRUD
  public boolean cadastrar(Curriculo csv) throws ClassNotFoundException {
    Connection conn = null;        
    try {           
        conn = ConectaDB.conectar();
        Statement stmt = conn.createStatement();

      String sql = "INSERT INTO candidatos (nome, email, telefone, formacao, experiencia, habilidades, linkedin, portfolio, salario) VALUES (" 
        + "'" + csv.getNome() + "', "
        + "'" + csv.getEmail() + "', "
        + "'" + csv.getTelefone() + "', "
        + "'" + csv.getFormacao() + "', "
        + "'" + csv.getXp() + "', "
        + "'" + csv.getHabilidades() + "', "
        + "'" + csv.getLinkedin() + "', "
        + "'" + csv.getPortfolio() + "', "
        + csv.getSalario() + ")";

        stmt.executeUpdate(sql); // Insert / Delete / Update
        System.out.println("Cadastrado com sucesso!");
        conn.close();
        return true;
    } catch(SQLException ex) {
        ex.printStackTrace(); 
        return false;
    }        
}

    public List<Curriculo> consulta_curriculo() throws ClassNotFoundException {
        List<Curriculo> lst = new ArrayList<>();
        Connection conn = null;        
        try {           
            conn = ConectaDB.conectar();
            Statement stmt = conn.createStatement();
            String sql = "SELECT * FROM candidatos ORDER BY nome";  
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                Curriculo csv = new Curriculo();
                csv.setId(rs.getInt("id")); 
                csv.setNome(rs.getString("nome"));
                csv.setEmail(rs.getString("email"));
                csv.setTelefone(rs.getString("telefone"));
                csv.setFormacao(rs.getString("formacao"));
                csv.setXp(rs.getString("experiencia"));
                csv.setLinkedin(rs.getString("linkedin"));
                csv.setPortfolio(rs.getString("portfolio"));
                csv.setSalario(rs.getInt("salario"));
               
                lst.add(csv);
            }

            conn.close();

            if (lst.isEmpty()) {
                return null;
            } else {             
                return lst;
            }            
        } catch(SQLException ex) {
            ex.printStackTrace();
            return null;
        }        
    }
    public Curriculo consulta_id(Curriculo csv) throws ClassNotFoundException {
        Connection conn = null;        
        try {           
            conn = ConectaDB.conectar();
            Statement stmt = conn.createStatement();
            String sql = "SELECT * FROM candidatos WHERE id = " + csv.getId();  
            ResultSet rs = stmt.executeQuery(sql);

            if (rs.next()) {
                csv.setNome(rs.getString("nome"));
                csv.setEmail(rs.getString("email"));
                csv.setTelefone(rs.getString("telefone"));
                csv.setFormacao(rs.getString("formacao"));
                csv.setXp(rs.getString("experiencia"));
                csv.setHabilidades(rs.getString("habilidades"));
                csv.setLinkedin(rs.getString("linkedin"));
                csv.setPortfolio(rs.getString("portfolio"));
                csv.setSalario(rs.getInt("salario"));
                return csv;
            } else {
                return null;
            }            

        } catch(SQLException ex) {
            ex.printStackTrace();
            return null;
        }        
    }
    public Curriculo consulta_nome(Curriculo usu) throws ClassNotFoundException {
        Connection conn = null;        
        try {           
            conn = ConectaDB.conectar();
            Statement stmt = conn.createStatement();
            String sql = "SELECT * FROM candidatos WHERE nome = '" + usu.getNome() + "'";  
            ResultSet rs = stmt.executeQuery(sql);

            if (rs.next()) {
                usu.setId(rs.getInt("id"));
                usu.setEmail(rs.getString("email"));
                usu.setTelefone(rs.getString("telefone"));
                usu.setFormacao(rs.getString("formacao"));
                usu.setXp(rs.getString("experiencia"));
                usu.setHabilidades(rs.getString("habilidades"));
                usu.setLinkedin(rs.getString("linkedin"));
                usu.setPortfolio(rs.getString("portfolio"));
                usu.setSalario(rs.getInt("salario"));
                return usu;
            } else {
                return null;
            }            

        } catch(SQLException ex) {
            ex.printStackTrace();
            return null;
        }        
    }  
    
   
    
    
}
