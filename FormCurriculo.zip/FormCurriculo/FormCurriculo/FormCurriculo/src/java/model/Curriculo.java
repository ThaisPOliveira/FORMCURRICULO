/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 * UNIVERSIDADE MOGI DAS CRUZES 
 * @author Matheus e Thais
 * Data: 21/08/2025 
 *              Nome
                Email
                Telefone
                Formação
                Experiência
                Habilidades
                Linkedin
                Portfolio
                Salario
 */
public class Curriculo {
    
    
    
    // Atributos
    private int id;
    private String nome;
    private String email;
    private String telefone;
    private String formacao;
    private String xp;
    private String habilidades;
    private String linkedin;
    private String portfolio;
    private int salario;

    /**
     * @return the id
     */
    public int getId() {
        return this.id;
    }

    public void setId(int p_id) {
        this.id = p_id;
    }

    /**
     * @return the nome
     */
    public String getNome() {
        return this.nome;
    }

  
    public void setNome(String p_nome) {
        this.nome = p_nome;
    }

    /**
     * @return the email
     */
    public String getEmail() {
        return this.email;
    }

  
    public void setEmail(String p_email) {
        this.email = p_email;
    }

    /**
     * @return the telefone
     */
    public String getTelefone() {
        return this.telefone;
    }

 
   public void setTelefone(String p_telefone) {
    if (p_telefone == null || !p_telefone.matches("^\\d{11}$")) {
    throw new IllegalArgumentException("O telefone deve conter 11 dígitos numéricos.");
    }
    this.telefone = p_telefone;
    }

    /**
     * @return the formacao
     */
    public String getFormacao() {
        return this.formacao;
    }

  
    public void setFormacao(String p_formacao) {
        this.formacao = p_formacao;
    }

    /**
     * @return the xp
     */
    public String getXp() {
        return this.xp;
    }


    public void setXp(String p_xp) {
        this.xp = p_xp;
    }

    /**
     * @return the habilidades
     */
    public String getHabilidades() {
        return this.habilidades;
    }


    public void setHabilidades(String p_habilidades) {
        this.habilidades = p_habilidades;
    }
    
      /**
     * @return the Linkedin
     */
    public String getLinkedin() {
        return this.linkedin;
    }


    public void setLinkedin(String p_linkedin) {
        this.linkedin = p_linkedin;
    }
     /**
     * @return the Portfolio
     */
    
    public String getPortfolio() {
        return this.portfolio;
    }


    public void setPortfolio(String p_portfolio) {
        this.portfolio = p_portfolio;
    }
    
     /**
     * @return the Salario
     */
    public  int getSalario() {
        return this.salario;
    }

    public void setSalario(int p_salario) {
        this.salario = p_salario;
    }
   
         
}
